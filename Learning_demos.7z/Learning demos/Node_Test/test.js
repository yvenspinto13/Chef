var fs=require('fs');

//files operations
/* fs.stat('C:/JavaScript/JavaScript/Assignment3.zip',function (err,stats) {
    console.log(stats);
    console.log('is File?'+ stats.isFile());
    console.log("is Directory"+stats.isDirectory());
})

fs.readdir('',function (err,files) {
    console.log(files);
}) */

if(!fs.exists("test_directory")){
    fs.mkdir("test_directory",0666,function (err) {
        if(err){
            console.log("Error occurred, cannot make directory" +err);
            console.log("will delete directory now");
            fs.rmdir("test_directory");
        }
        else{
            console.log("making directory");
        }
    })
}