var express = require('express'),
    app = express(),
    port = 1234,
    itemRouter = require('./src/routes/itemRoutes'),
    mongoose = require('mongoose'),
    bodyParser = require('body-parser'),
    tunnelingAgent = require('./src/agent/agent'),
    http = require('http');


app.set('view engine', 'ejs');

app.use(express.static('public'));

app.use('/items', itemRouter);

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json())

//AWHXqz1KC8NpO9hbWpzTX7VnS0TPgDOO

/* var req = http.request({
    host:'https://api.mlab.com/api/1/databases/nodeitems/collections?apiKey=AWHXqz1KC8NpO9hbWpzTX7VnS0TPgDOO',
    agent : tunnelingAgent
}) */

console.log(process.env.https_proxy);

mongoose.Promise = require('bluebird');
mongoose.connect('mongodb://yvenspinto13:ind%236a23FoDhO9@ds239137.mlab.com:39137/nodeitems')
    .then(() => {
        console.log('connected');
    })
    .catch(err => {
        console.error('App starting error', err.stack);
        process.exit(1)
    })

app.listen(port, function () {
    console.log("yeay");
})

app.use('/', function (req, res) {
    /*  Item.find(function (err,items) {
         if(err) {
             console.log(err);
         }
         else {
             res.render('items',{itms: itms});
         }
     }); */
     
});

// var fs = require('fs');
var fs = require('fs');
fs.mkdir()
var stream = fs.createReadStream('package.json')
stream.on('data',function (file) {

    console.log(file.toString());
})
