var http= require('http')

var options = {
    host:'127.0.0.1',
    port:1234,
    path:'/',
    method:'GET'
};

var req = http.request(options,function (res) {
    console.log("Status Code "+res.statusCode);
    console.log("Response :" + res);
})

req.end();