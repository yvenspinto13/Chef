var http= require('http'),
    url= require('url');


//normal server with context as type 
/* var server = http.createServer(function (request,response) {
    response.writeHead(200,{
        'Content-Type':'text/plain'
    });
    response.write('Hello from server');
    response.write('So many nodejs web apps')
    response.end();
}) */


var server=http.createServer();

server.on("request", function (req,res) {
    if(req.method === 'GET'){
        var url_parts=url.parse(req.url,true);
        var query = url_parts.query;
        console.log(query);
    }

    //for post request
    req.on("readable",function () {
        console.log("readable" + req.read);
    })
})

server.listen(1234,'127.0.0.1')
console.log('Server added at http://127.0.0.1:1234');