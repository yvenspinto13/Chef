var mongoose = require('mongoose'),
    a= require('t')
    Schema = mongoose.Schema;

var Item = new Schema({
    item:{
        type:String,
        unique:true
    },
},{
    collection:'items'
});



module.exports = mongoose.model('Item',Item);