var tunnel = require('tunnel');

var tunnelingAgent = tunnel.httpsOverHttp({
    proxy: {
        proxyAuth : '',

        headers: {
            'User-Agent' : 'Node'
        }
    }
});

module.exports = tunnelingAgent;