var express = require('express'),
    app = express(),
    itemRouter = express.Router(),
    Item = require('../models/Item'),
    http = require('http'),
    tunnelingAgent = require('../agent/agent');

itemRouter.route('/').get(function (req, res) {
    res.render('items')
})

itemRouter.route('/single').get(function (req, res) {
    res.render('singleItem');
    
})

itemRouter.route('/add').get(function (req,res) {
    res.render('addItem');
})

itemRouter.route('/add/post').post(function (req,res) {
    var item = new Item(req.body);

    http.request({
        url: 'https://api.mlab.com/api/1/databases/nodeitems/collections/items?apiKey=AWHXqz1KC8NpO9hbWpzTX7VnS0TPgDOO',
        data : JSON.stringify(item),
        type : 'POST',
        contentType : 'application/json',
        agent :tunnelingAgent
    })

    item.save()
        .then(item => {
            res.redirect('/');
        })
        .catch(err => {
            res.status(400).send("unable to save to database");
        });
});

module.exports = itemRouter;