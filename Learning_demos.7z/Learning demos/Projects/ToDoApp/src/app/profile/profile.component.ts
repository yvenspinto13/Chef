import { Component, OnInit } from '@angular/core';
import { SessionStorage } from 'ngx-webstorage';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  @SessionStorage('user')
  newname:string;

  constructor() { }

  ngOnInit() {

  }

}
