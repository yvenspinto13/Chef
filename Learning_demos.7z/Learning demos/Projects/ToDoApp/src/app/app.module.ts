import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Ng2Webstorage } from 'ngx-webstorage';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { TodolistComponent } from './todolist/todolist.component';
import { TodoitemComponent } from './todoitem/todoitem.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { SummaryComponent } from './summary/summary.component';
import { CompletedListComponent } from './completed-list/completed-list.component';
import { PendingListComponent } from './pending-list/pending-list.component';


import { TodoitemsService } from './todoitems.service';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'todolist/:user', component: TodolistComponent, children: [
    {path : 'pending', component: PendingListComponent},
    { path: 'completed', component: CompletedListComponent}
  ] },
  { path: 'summary', component: SummaryComponent },
  { path: 'profile', component: ProfileComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    TodolistComponent,
    TodoitemComponent,
    LoginComponent,
    ProfileComponent,
    SummaryComponent,
    CompletedListComponent,
    PendingListComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    Ng2Webstorage,
    HttpClientModule
  ],
  providers: [TodoitemsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
