import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStorage } from 'ngx-webstorage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @SessionStorage('user')
  name: string= '';
  password: string= '';
  
  constructor(private router:Router){}

  ngOnInit() {
  }

  postForm():void{
    if(this.name=='admin' && this.password=="admin"){
      this.router.navigate(['todolist',this.name])
    }
    else {
      alert("Invalid credentials")
    }
  }
}
