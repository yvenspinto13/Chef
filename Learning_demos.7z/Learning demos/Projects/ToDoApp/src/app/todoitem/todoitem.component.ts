import { Component, Input, OnInit } from '@angular/core';
import { ToDo } from '../toDo';
import { TodoitemsService } from '../todoitems.service';

@Component({
  selector: 'app-todoitem',
  templateUrl: './todoitem.component.html',
  styleUrls: ['./todoitem.component.css']
})
export class TodoitemComponent implements OnInit {

  @Input()
  itemChild:number;
  toDoItems:Array<ToDo>;
  item:ToDo;
  constructor(private toDoItemsService: TodoitemsService) {
    this.toDoItems = toDoItemsService.getItems();
  }

  ngOnInit() {
    this.item=this.toDoItems[this.itemChild];
  }

  markComplete(): void {
    this.item.done=true;
  }
}