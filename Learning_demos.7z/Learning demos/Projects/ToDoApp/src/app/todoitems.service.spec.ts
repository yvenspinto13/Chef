import { TestBed, inject } from '@angular/core/testing';

import { TodoitemsService } from './todoitems.service';

describe('TodoitemsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TodoitemsService]
    });
  });

  it('should be created', inject([TodoitemsService], (service: TodoitemsService) => {
    expect(service).toBeTruthy();
  }));
});
