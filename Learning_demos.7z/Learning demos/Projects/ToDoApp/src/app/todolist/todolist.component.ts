import { Component, OnInit } from '@angular/core';
import { TodoitemsService } from '../todoitems.service';
import { Observable } from 'rxjs/Rx';

import { ActivatedRoute } from '@angular/router';
import { ToDo } from '../toDo';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css'],
})
export class TodolistComponent implements OnInit {
  toDoItems: Observable<ToDo>;
  isActive: Array<boolean>=new Array<boolean>();
  item: number;
  clean: string = '';
  user: string = '';
  state:boolean=false;

  constructor(private toDoItemsService: TodoitemsService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(routeParams=>{
      this.user = routeParams['user']
    });
    this.toDoItems = this.toDoItemsService.getObv()
    this.isActive = new Array<boolean>(this.toDoItemsService.getTotal());
    this.isActive.fill(false);
  }

  addItem(title: string, dueDate: Date): void {
    this.toDoItemsService.addItem(new ToDo(title, false, new Date(), dueDate))
    this.clean = null;
  }

  removeItem(index: number): void {
    this.toDoItemsService.removeItem(index)
    this.isActive[index]=false;
  }

  showDetails(index: number): void{
    if(this.isActive[index]==true){
      this.isActive[index]=false
    }
    else{
      this.isActive[index]=true;
    }
    this.item=index;
  }
}
