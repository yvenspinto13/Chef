import { Component, OnInit } from '@angular/core';
import { TodoitemsService } from '../todoitems.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

  sum:number;
  constructor(private toDoItemsService: TodoitemsService) { }

  ngOnInit() {
    this.sum=this.toDoItemsService.getTotal()
  }

}
