export class ToDo {
    title: string;
    done: boolean;
    creationDate: Date;
    dueDate: Date;
    constructor(title: string, done: boolean, creationDate: Date, dueDate: Date) {
        this.title = title;
        this.done=done;
        this.creationDate=creationDate;
        this.dueDate=dueDate;
    }
}