import { Component, OnInit, DoCheck } from '@angular/core';
import { TodoitemsService } from '../todoitems.service';
import { ToDo } from '../toDo';

@Component({
  selector: 'app-pending-list',
  templateUrl: './pending-list.component.html',
  styleUrls: ['./pending-list.component.css']
})
export class PendingListComponent implements OnInit,DoCheck {


    items:Array<ToDo>;

  constructor(private itemService:TodoitemsService) {
    this.items=new Array<ToDo>()
   }

  ngOnInit() {
    this.items = this.itemService.getNotCompletedItems(); 

  }

  ngDoCheck() {
    this.items = this.itemService.getNotCompletedItems(); 
  }
}
