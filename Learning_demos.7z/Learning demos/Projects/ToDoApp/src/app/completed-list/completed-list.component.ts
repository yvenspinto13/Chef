import { Component, OnInit, DoCheck } from '@angular/core';
import { TodoitemsService } from '../todoitems.service';
import { ToDo } from '../toDo';
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'app-completed-list',
  templateUrl: './completed-list.component.html',
  styleUrls: ['./completed-list.component.css']
})
export class CompletedListComponent implements OnInit, DoCheck {

  items:Array<ToDo>;
  
  constructor(private itemService:TodoitemsService) { 
    this.items=new Array<ToDo>();
  }

  ngOnInit() {
    this.items=this.itemService.getCompletedItems();
  }

  ngDoCheck(){
        this.items=this.itemService.getCompletedItems();
  }
}
