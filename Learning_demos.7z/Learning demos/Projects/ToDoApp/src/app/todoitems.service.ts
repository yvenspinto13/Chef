import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs/Rx';

import { ToDo } from './toDo';

@Injectable()
export class TodoitemsService {

  toDoItems: Array<ToDo>;
  data: Subject<any> = new Subject<any>();

  constructor(private http: HttpClient) {
    this.toDoItems = new Array<ToDo>();
  }

  getItems(): Array<ToDo> {
    this.toDoItems.push(new ToDo('Wash the Car', false, new Date('2017-09-22'), new Date()));
    this.toDoItems.push(new ToDo('Wash the Bike', false, new Date('2017-12-4'), new Date()));
    this.toDoItems.push(new ToDo('Wash the Clothes', true, new Date('2017-12-3'), new Date()));
    this.toDoItems.push(new ToDo('Cook Food', false, new Date(), new Date()));
    return this.toDoItems;
  }

  getItemsFromServer(): Observable<any> {
    //console.log("items from server")
    return this.http.get("http://jsonplaceholder.typicode.com/todos");
  }

  //checking for observable
  getObv(): Observable<ToDo> {
    this.toDoItems = []
    this.toDoItems = this.getItems();
    this.getItemsFromServer().subscribe(data => {
      let temp = data;
      let d = new Date();
      d.setDate(d.getDate() + 3)
      temp.forEach(element => {
        this.toDoItems.push(new ToDo(element.title, element.completed, new Date(), d))
      })
      this.data.next(this.toDoItems)
    });
    return this.data.asObservable();
  }

  getTotal(): number {
    return this.toDoItems.length;
  }

  addItem(item: ToDo): void {
    this.toDoItems.push(item)
  }

  removeItem(index: number): void {
    this.toDoItems.splice(index, 1)
  }

  //returng array 
  getCompletedItems(): Array<ToDo> {
    return this.toDoItems.filter(function (obj: ToDo) {
      if (obj.done == true) return obj;
    })
  }

  //return array
  getNotCompletedItems(): Array<ToDo> {
    return this.toDoItems.filter(function (obj: ToDo) {
      if (obj.done == false) return obj;
    })
  }
  
}
