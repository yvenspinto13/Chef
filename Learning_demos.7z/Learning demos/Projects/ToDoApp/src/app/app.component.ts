import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  user = '';
  state:boolean=true;
  constructor(private storage: SessionStorageService){ }

  ngOnInit(){
    this.storage.observe('user')
        .subscribe((newValue) => {
          this.user = newValue;
          if(this.user !='') this.state=false;
          else this.state=true;
        });
  }
}
