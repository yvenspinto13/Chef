export class User{
    username:string;
    admin:boolean;

    constructor(name:string,admin:boolean){
        this.username=name;
        this.admin=admin;
    }
}

export interface RegisterUser {
     name: string;
     phone: string;
     address: string;

}