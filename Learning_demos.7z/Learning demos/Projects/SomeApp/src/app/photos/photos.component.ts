import { Photo } from '../photo';
import { Component, OnInit } from '@angular/core';
import { PhotosService } from '../photos.service';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css'],
  providers:[PhotosService]
})
export class PhotosComponent implements OnInit {

  photosArray:Array<Photo>=new Array<Photo>();

  constructor(private photosService:PhotosService) { }

  ngOnInit() {
    /*
    Using observables 
    this.photosService.getPhotos().subscribe(data=>{
      //console.log(data);
      this.photosArray=data
      console.log(this.photosArray[1]);
    }); */

    //using promises
   /*  this.photosService.getPhotos().then(response=>{
      console.log(response)
      this.photosArray=response;
    }); */
  }

}
