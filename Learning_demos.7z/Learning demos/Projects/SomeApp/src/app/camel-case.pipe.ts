import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'camelCase'
})
export class CamelCasePipe implements PipeTransform {

  transform(inputValue: string, args?: any): any {
    //logic to convert first letter to capital
    if(!inputValue) return inputValue;
    return inputValue.replace(/\w\S*/g,function(txt){
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    })
  }

}
