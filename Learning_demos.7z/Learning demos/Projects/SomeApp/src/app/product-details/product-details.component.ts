import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ProductsServiceA,ProductsServiceB } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  products:any;
  pId: number;
  product:Product;

  constructor(private activateRoute:ActivatedRoute,private productService:ProductsServiceA) { }

  ngOnInit() {
    //fetch trhe route parameter
    this.activateRoute.params.subscribe(routeParams=>{
      //handler will execute when param changes
      //route params is an array of all route parameters
      console.log(routeParams)
      this.pId=parseInt(routeParams['productid'])
      this.products=this.productService.getProducts();
      this.products.forEach(element => {
        if(element.id==this.pId){
          this.product=element;
          //break;
        }
      });
    })
  }

}
