import { Component, OnInit } from '@angular/core';
import { ProductsServiceA } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cart_list:Array<Product>=new Array<Product>();
  goals:Array<any>=new Array<any>();
  //bound value works
  //@LocalStorage()
  //val:string="hey"

  constructor(private productService: ProductsServiceA) { }

  ngOnInit() {
    //console.log(this.productService.getCartProducts());
    /* this.productService.getCartProducts().subscribe(data=>{
      //console.log(data)
      this.cart_list.push(data)
    }); */
   console.log(this.productService.getCartProducts())
    this.cart_list=this.productService.getCartProducts()
  }

  deleteFromCart(index:number):void{
    this.productService.addToProductFromCart(this.cart_list[index]);
    //let obj=JSON.stringify(this.cart_list[index]);
    //let obj_id=this.cart_list[index].id+"";
    //console.log(obj);
    this.cart_list.splice(index, 1);

    //deleting from store using web storage package

    //using local storage object by itself works
    //localStorage.setItem(obj_id,JSON.stringify(this.cart_list[index]));
    //this.val="put"
  }

  //local storage stores as string
  //localStorage.setItem('user', JSON.stringify(user))
  //var user = JSON.parse(localStorage.getItem('user'))
}
