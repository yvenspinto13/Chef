import { Injectable } from '@angular/core';
import { Product} from './product'

@Injectable()
export class ProductsService{
    getProducts():Array<Product>{
        return null
    };
}