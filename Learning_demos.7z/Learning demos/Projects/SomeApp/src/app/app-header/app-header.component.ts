import { Component, OnInit } from '@angular/core';

import { LoginService } from '../login.service';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css'],
})
export class AppHeaderComponent implements OnInit {

  //can be of string or object
  username:string;
  //if needed use for ngIf
  //isActive:boolean=false;

  constructor(private loginService: LoginService) {
    /* this is for getting strings or simple json objects 
    this.loginService.getName().subscribe(newname=>{
      //whenever new name is received
      console.log(newname);
      this.username=newname;
      this.isActive=true;
    }) */

    this.loginService.getUser().subscribe(newuser=>{
      this.username=newuser.username;
    })
  }

  ngOnInit() {
  }

}
