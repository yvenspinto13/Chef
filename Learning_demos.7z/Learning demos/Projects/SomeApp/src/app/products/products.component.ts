import { Component, Input, Output, OnInit } from '@angular/core';
import { Product } from '../product';

import { ProductsService } from '../productsService.service';
import { ProductsServiceA,ProductsServiceB } from '../products.service';
import { LoginService } from '../login.service';

@Component({
    selector: 'app-products',
    templateUrl:'./products.component.html',
    styleUrls:['./products.component.css'],
})
export class ProductsComponent implements OnInit {
    products: Product[] //alternate Array<Product>
    isAdmin:boolean=false;
    product_list=[];
   // test:number[]=[10,15,16,17,18];
    /*
    1. Dependencies-- ProductService 
        --dependencies are always injected in the constructor 
    2. Injector-- Angular 2 injector
    3. Providers
     */
    constructor(private productService:ProductsServiceA,private loginService:LoginService) {
        //initialize the list
        //fetch it from the service
        console.log("Constructor of product component called");
        this.products=productService.getProducts();
        this.loginService.getUser().subscribe(newuser=>{
            this.isAdmin=newuser.admin;
        })
        //trying

        //console.log(this.products);
    }

    ngOnInit(){
       /*  this.productService.goal.subscribe(res=>{
            this.product_list=res
        })
        this.productService.changeList(this.product_list) */
    }

    remove(index:number):void{
        //remove the element from the array
        this.products.splice(index,1); //splice is used to delete from an array
    }

    validate(searchStr:string):void{
        //you need input value of text box
        console.log("searchstr "+searchStr);
    }

    add(index:number):void{
        this.productService.addToCart(this.products[index]);
        this.remove(index)
    }
}
