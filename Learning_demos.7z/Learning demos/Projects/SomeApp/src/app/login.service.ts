import { User } from './user';
import { Injectable } from '@angular/core';

import { Observable, Subject } from 'rxjs/Rx';

@Injectable()
export class LoginService {

  //for normal strings
  //nameSubj: Subject<string> = new Subject<string>();

  //for objects
  userSubj: Subject<User> =new Subject<User>();
  loggedIn:boolean=false;

 /* for strings 
  setName(obj):void{
    //add the new name to the subject(add it as a stream of bytes)
    this.nameSubj.next(obj)
  }

  getName(): Observable<string>{
    //invoked by the header component
    return this.nameSubj.asObservable(); //as a stream of values
  } */

  //for objects
  setUser(obj:User):void{
    this.userSubj.next(obj)
    this.loggedIn=true;
  }

  getUser():Observable<User>{
    return this.userSubj.asObservable();
  }

  isLoggedIn():boolean{
    return this.loggedIn;
  }
}
