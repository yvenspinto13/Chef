import { Observable, Subject } from 'rxjs/Rx';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Photo } from './photo';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class PhotosService {

  data:Subject<any>=new Subject<any>();

  constructor(private http: HttpClient) {
   }

   //observable
  /* getPhotos():Observable<any>{
    return this.http.get("http://jsonplaceholder.typicode.com/photos");
  } */

  //promise
  getPhotos():Promise<any>{
    return this.http.get("http://jsonplaceholder.typicode.com/photos").toPromise();
  }

}
