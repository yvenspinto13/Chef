import { Component,OnInit } from '@angular/core';

import { UserDetails } from './profile/userDetails';
import { LoginService } from './login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 // For objects 
  title:UserDetails; 
  status:boolean;
  /* for strings */
  /* title:string="Jane Doe" */
  constructor(private loginService:LoginService){
    this.title=new UserDetails("Jacob",12344445,"fancy land")
  }

  ngOnInit(){
    this.status=this.loginService.isLoggedIn();
    console.log("status"+this.status)
  }

  handleUpdate(newValue:string):void{
    //get the new value that has been emitted
   // this.title=newValue;
  }
}
