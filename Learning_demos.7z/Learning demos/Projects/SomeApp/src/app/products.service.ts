import { Injectable } from '@angular/core';
import { Product } from './product';
import { Subject, Observable, BehaviorSubject} from 'rxjs';

import { ProductsService } from './productsService.service';

import { LocalStorageService } from 'ngx-webstorage';


@Injectable()
export class ProductsServiceA {
    products: Product[];
    cart_list: Subject<Product> = new Subject<Product>();
    cart_list_store: Product[]=new Array<Product>();
    product_cart:Product[]=new Array<Product>()

    constructor(private localStore:LocalStorageService) {
        //super();
        console.log("Constructor of product service called");
        //alternate way of initializing is using new Array<Product>();
        this.products = [new Product(12, 'phone', 12, '../assets/images/1.jpg'), new Product(11, 'laptop', 55, '../assets/images/3.jpg')];
        //once initialised you can use push
        this.products.push(new Product(17, 'phone', 12, '../assets/images/2.jpg'), new Product(19, 'phone', 22, '../assets/images/1.jpg'))
        //console.log(this.products);
    }

    getProducts(): Array<Product> {
        //console.log(this.products);
        console.log("called get products");
        return this.products;
    };

    addToCart(product: Product): void {
        this.cart_list.next(product);
        this.changeList(product)
        //check this
        /* this.cart_list_store.push(product)
        this.localStore.store(product.id+"", JSON.stringify(product)) */
    }

    getCartProducts(): Array<Product> {
       // return this.cart_list.asObservable();
       return this.product_cart;
    }

    addToProductFromCart(product:Product):void{
       // this.localStore.clear(product.id + "")
        this.products.push(product)
    }

    changeList(product){
        console.log("change list called ");
        this.product_cart.push(product)
    }
}

@Injectable()
export class ProductsServiceB extends ProductsService {
    products: Product[]
    cart_list:Subject<Product>=new Subject<Product>()

    constructor() {
        super();
        console.log("Constructor of product service called");
        //alternate way of initializing is using new Array<Product>();
        this.products = [new Product(12, 'phone', 12, '../assets/images/1.jpg'), new Product(11, 'laptop', 55, '../assets/images/3.jpg')];
        //once initialised you can use push
        // this.products.push(new Product(17, 'phone', 12, '../assets/images/2.jpg'), new Product(19, 'phone', 22, '../assets/images/1.jpg'))
        //console.log(this.products);
    }
    getProducts(): Array<Product> {
        return this.products;
    };
    
    addToCart(product:Product):void{
        this.cart_list.next(product);
    }

    getCartProducts():Observable<Product>{
        return this.cart_list.asObservable();
    }
}

/* 
instead of using inheritance using a class (ProductsService) we can make an interface.
The interface has to be exported and cannot be made injectable
For {provide:'interface_name',useClass:class_name}
In constructor constructor(@Inject('interface_name') private whatever:Interface_name)
*/