export class UserDetails {
    name:string;
    contact:number;
    address:string;

    constructor(name:string,contact:number,address:string) {
        this.name=name;
        this.contact=contact;
        this.address=address;
    }
}