import { UserDetails } from './userDetails';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  @Input()
  /* username:string; */
  username:UserDetails;
  /*this updates every where
   */ //this var will get the same value from parent

  constructor() { }

  //custome event update
  @Output()
  update:EventEmitter<string> =new EventEmitter<string>()

  ngOnInit() {
  }

  updateName():void{
    //trigger a custom event update
    //this.update.emit(this.username)
  }
}
