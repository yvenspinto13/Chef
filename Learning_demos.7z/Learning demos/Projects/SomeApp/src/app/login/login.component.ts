import { Component } from '@angular/core';
import { LoginService } from '../login.service';
import { User } from '../user';

import { Router } from '@angular/router'


@Component({
    selector:`login`,
    templateUrl:'./login.component.html',
})
export class LoginComponent{
    user_name:string='admin';
    password:string="admin";
    isAdmin:boolean=false;
    user:User;

    constructor(private loginService:LoginService,private router: Router){
    }

    submit():void{
        console.log("Username:"+this.user_name+" Password "+this.password);
        if(this.user_name=="admin" && this.password=="admin"){
            alert("hello admin");
            this.isAdmin=true;
        }
        //using string and json objects (string just send as one argument)
        //this.loginService.setName({"username": this.user_name, "admin": this.isAdmin})

        //to send object user
        this.user=new User(this.user_name,this.isAdmin);
        this.loginService.setUser(this.user);
        //to prevent reload
        this.router.navigate([''])
    }

    logout():boolean{
        if(this.user.username!=null){
            this.user.username=null;
            this.user.admin=false;
            this.loginService.setUser(this.user);
            alert("Logged out")
        }
        else{
            alert("Log in first")
        }
        return false;
    }
}