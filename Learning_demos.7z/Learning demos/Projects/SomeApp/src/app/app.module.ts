import { LoginService } from './login.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatTabsModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2Webstorage } from 'ngx-webstorage';
import { RouterModule,Routes } from '@angular/router';

import { AppComponent } from './app.component';  //typecript imports, nothing to do with angular
import { ProductsComponent } from './products/products.component';
import { LoginComponent } from './login/login.component';
import { MobileProductsComponent } from './mobile-products/mobile-products.component';
import { ProfileComponent } from './profile/profile.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { PhotosComponent } from './photos/photos.component';
import { CartComponent } from './cart/cart.component';

import { ProductsService } from './productsService.service';
import { ProductsServiceA } from './products.service';
import { ErrorComponent } from './error/error.component';
import { AllProductsComponent } from './all-products/all-products.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { RegisterComponent } from './register/register.component';
import { CamelCasePipe } from './camel-case.pipe'; 

let routes: Routes= [
  { path: 'login', component: LoginComponent },
  { path: '', component: ProductsComponent, children: [
    {path:'mobile', component: MobileProductsComponent},
    {path:'allproducts', component: AllProductsComponent, children: [
    { path: 'productdetails/:productid', component: ProductDetailsComponent}
  ]
  }]},
  {path:'photos',component:PhotosComponent},
  {path:'cart',component:CartComponent},
  {path:'register',component:RegisterComponent},
  {path:'**',component:ErrorComponent}
];

@NgModule({
  declarations: [    //list of modules that belong to appcomponent
    AppComponent,
    ProductsComponent,
    LoginComponent,
    MobileProductsComponent,
    ProfileComponent,
    AppHeaderComponent,
    PhotosComponent,
    CartComponent,
    ErrorComponent,
    AllProductsComponent,
    ProductDetailsComponent,
    RegisterComponent,
    CamelCasePipe
  ],
  imports: [        //declare modules that are needed to be imported for angular
    BrowserModule,  //browser module internally includes by default core module,therefore you get features from core module too
    FormsModule,
    MatTabsModule,
    BrowserAnimationsModule,
    Ng2Webstorage,
    RouterModule.forRoot(routes),
    HttpClientModule  //for various requests (get,post ,put)
  ],
  providers: [LoginService,ProductsServiceA],
  bootstrap: [AppComponent] //Root component
})
export class AppModule { }
