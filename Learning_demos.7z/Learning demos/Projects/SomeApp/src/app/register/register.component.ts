import { Component, OnInit } from '@angular/core';
import { RegisterUser } from '../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: RegisterUser = {
            name : 'James',             
            phone:"1234",
            address:'India'
        
  }

  constructor() { }

  ngOnInit() {
  }

  postForm():void{
    alert("form posted")
    this.user.name=null;
    this.user.phone=null;
    this.user.address=null;
  }
}
