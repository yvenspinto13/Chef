import { Component, OnInit } from '@angular/core';
import { ProductsServiceA, ProductsServiceB } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {

  products: Product[]
  constructor(private productService: ProductsServiceA) { 
    this.products = productService.getProducts();
  }

  ngOnInit() {
  }

}
