import { Component, Input, OnInit, SimpleChange } from '@angular/core';

import { Product } from '../product';
import { ProductsService } from '../productsService.service';
import { ProductsServiceA, ProductsServiceB } from '../products.service';

@Component({
  selector: 'mobile-products',
  templateUrl: './mobile-products.component.html',
  styleUrls: ['./mobile-products.component.css']
})
export class MobileProductsComponent implements OnInit {

  mproducts: Product[]
  @Input() some: Product[];
  constructor(private productService: ProductsServiceA) {
    console.log("Constructor of product component called");
    //console.log("some"+this.some);
    this.mproducts = this.productService.getProducts().filter(function (product: Product) {
      return product.name == "phone";
    });
  }

  ngOnInit() {
  }

}


