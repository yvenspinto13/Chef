(function($){
    $.fn.colorit=function () {
        this.css("color","red").css("fontSize","42pt");
    }
})(jQuery);


(function ($) {
    $.fn.gold = function (options) {
        var settings = $.extend({
            color: "gold",
        }, options);
        return this.css({
            color: settings.color,
        });
    };

}(jQuery));
