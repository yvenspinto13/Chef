 include_recipe 'apt'

#load mysql passwords from data bag
passwords = data_bag_item('passwords','mysql')

#configure my sql service
mysql_service 'javawebapp' do
  initial_root_password passwords['root_password']
  port '3306'
  action [:create,:start]
  not_if { ::File.exist?('/var/run/mysql-javawebapp/mysqld.sock') }
end

cookbook_file '/home/hadoop/Room_db.sql' do
  source 'RoomBookFinal_db.sql'
  owner 'javawebapp_user'
  group 'javawebapp_group'
  mode '0644'
end 

bash 'dump mysql db' do
  code <<-EOH
    cd /home/hadoop/
    mysql -S /var/run/mysql-javawebapp/mysqld.sock -P3306 -p#{passwords['root_password']} < Room_db.sql
    EOH
  only_if {  ::File.exist?('/var/run/mysql-javawebapp/mysqld.sock') }
end

