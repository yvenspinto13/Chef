#just a quick fix for starting and stopping the tomcat service you have made

#stop the tomcat service
tomcat_service 'javawebapp' do
  action :stop
  tomcat_user 'javawebapp_user'
  tomcat_group 'javawebapp_group'
end

#start the tomcat service
tomcat_service 'javawebapp' do
  action :start
  tomcat_user 'javawebapp_user'
  tomcat_group 'javawebapp_group'
end

