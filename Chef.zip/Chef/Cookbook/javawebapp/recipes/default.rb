#
# Cookbook:: javawebapp
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

#include_recipe 'javawebapp::tomcat_server'
#include_recipe 'javawebapp::replace_war'
#include_recipe 'javawebapp::database'
#include_recipe 'javawebapp::handle_tomcat_service'
#include_recipe 'javawebapp::package_database'
