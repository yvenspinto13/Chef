#make sure java is installed
#java jdk defualts to 8
include_recipe 'java'

#make a group for java web app 
group 'javawebapp_group' do
  action :create
end

#install tomcat to default location and default permissions
tomcat_install 'javawebapp' do
  tarball_uri 'https://archive.apache.org/dist/tomcat/tomcat-8/v8.0.47/bin/apache-tomcat-8.0.47.tar.gz'
  tomcat_user 'javawebapp_user'
  tomcat_group 'javawebapp_group'
end

#upload a sample war file to tomcat
cookbook_file '/opt/tomcat_javawebapp/webapps/RoomBookFinalWar.war' do
  owner 'javawebapp_user'
  mode '0664'
  source 'RoomBookFinalWar.war'
  notifies :restart, 'tomcat_service[javawebapp]'
end

#start the service
tomcat_service 'javawebapp' do
  action :start
  tomcat_user 'javawebapp_user'
  tomcat_group 'javawebapp_group'
end
