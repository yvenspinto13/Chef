include_recipe = 'apt'

bash 'setting the db password' do
  code <<-EOH
    cd /home/hadoop/
    sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password password root'
    sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password root'
    EOH
end

apt_package 'mysql-server' do
  options '-y'
  action :install
end

apt_package 'mysql-client' do
  options '-y'
  action :install
end

#the config file you want to use, by default my.cnf is added with password and username as root
cookbook_file '/etc/mysql/my.cnf' do
  source 'my.cnf'
  mode '0664'
end

#okay copy the sql db file you want to dump mysql with
cookbook_file '/home/hadoop/Room_db.sql' do
  source 'RoomBookFinal_db.sql'
  owner 'javawebapp_user'
  group 'javawebapp_group'
  mode '0644'
end

bash 'dump mysql db' do
  code <<-EOH
    cd /home/hadoop/
    mysql < Room_db.sql
    EOH
  only_if {  ::File.exist?('/var/run/mysqld/mysqld.sock') }
end



