#stop the service
tomcat_service 'javawebapp' do
  action :stop
end

#clear the tomcat web app folder
bash 'clear webapps folder' do
  user 'root'
  code <<-EOH
  sudo rm -rf /opt/tomcat_javawebapp/webapps/RoomBookFinalWar
  EOH
  only_if {  ::File.exist?('/opt/tomcat_javawebapp/webapps/RoomBookFinalWar/')}
end

#copy and replace the new war file
#jenkins copies the warfile to the /warfiles directory, use that war file
#additional checks could be made to check how many war files exist in the directory
#since jenkins deletes all files first in the warfiles directory chef is expecting only one to be there
bash 'copy war file from /warfiles to tomcat webapps' do
  user 'javawebapp_user'
  code <<-EOH
  cp /warfiles/*war /opt/tomcat_javawebapp/webapps/RoomBookFinalWar.war
  EOH
  notifies :restart,'tomcat_service[javawebapp]'
end

#restart the tomcat service so the new war is deployed
tomcat_service 'javawebapp' do
  action :restart
  tomcat_user 'javawebapp_user'
  tomcat_group 'javawebapp_group'
end
