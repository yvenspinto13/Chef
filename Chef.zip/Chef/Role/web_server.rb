name "web_server"
description "A role to configure our front-line web servers"
run_list "recipe[apt]", "recipe[javawebapp]"
env_run_lists "_default"=>[], "production" => ["recipe[javawebapp::replace_war]"], "development" => ["recipe[javawebapp::tomcat_server]","recipe[javawebapp::package_databse]"]
